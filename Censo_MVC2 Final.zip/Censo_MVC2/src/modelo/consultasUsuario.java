/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *
 * @author Oscar
 */
public class consultasUsuario extends Conexion{

    public boolean verificarUsuario(Usuario usuario) throws SQLException {
   
    PreparedStatement stmt = null;
    Connection con = null;
    ResultSet rs = null;
       
    
    try {
        con = getConexion();
        
        String SQL = "SELECT * FROM login_usuario WHERE usuario = ? AND pass = ?";
        stmt = con.prepareStatement(SQL);
        stmt.setString(1, usuario.getUsuario());
        stmt.setString(2, usuario.getPass());
        rs = stmt.executeQuery();
        
        boolean encontrado = false;
        
        while (rs.next()) {
            encontrado = true;
        }
        
        return encontrado;
    } catch (SQLException e) {      
        return false;
    } finally {

        if (con != null) {
            con.close();
        }
    }
}
}

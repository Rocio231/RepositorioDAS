/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import modelo.Habitante;
import modelo.Ocupacion;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Conexion;
import vista.frmMenuOp;
import vista.Dashboard;
import vista.frm_agregarCenso;
import modelo.Vivienda;
import modelo.consultasHabitante;
import modelo.consultasHabitanteOcupacion;
import modelo.consultasOcupacion;
import modelo.consultasVivienda;

public class CtrlMenu extends Conexion implements ActionListener {

    private final frmMenuOp vistam;
    private final frm_agregarCenso vistaAgregar;
    private Dashboard vistaD;

    public CtrlMenu(frmMenuOp vistam) {
        
        this.vistam = new frmMenuOp();
        this.vistaAgregar = new frm_agregarCenso();
        this.vistaD = new Dashboard();
        this.vistam.btn_agregarCenso.addActionListener(this);
        this.vistam.btn_salir.addActionListener(this);
        //this.vistaD.btn_salird.addActionListener(this);
     this.vistaAgregar.btn_salirCenso.addActionListener(this);
        this.vistam.btn_dashboard1.addActionListener(this);
    }

    public void iniciar() {
        vistam.setTitle("Menu de Opciones");
        vistam.setLocationRelativeTo(null);
        vistam.setVisible(true);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
      
        
        
        if (e.getSource() == vistam.btn_agregarCenso) { //se verifica si el evento proviene del botón "btn_agregarCenso"

            frm_agregarCenso frmAgregar = new frm_agregarCenso();

            CtrlVivienda ctrlvivienda = new CtrlVivienda(new Vivienda(), new consultasVivienda(), frmAgregar);
            CtrlHabitante ctrlhabitante = new CtrlHabitante(new Habitante(), new consultasHabitante(), frmAgregar);
            CtrlOcupacion ctrlocupacion = new CtrlOcupacion(new Ocupacion(), new Habitante(), new consultasOcupacion(), new consultasHabitanteOcupacion(), new consultasHabitante(), frmAgregar);

            ctrlvivienda.iniciar();
            ctrlhabitante.iniciar();
            ctrlocupacion.iniciar();
            
            // DESDE LA VISTA DE AGREGAR DARLE LA ACCION AL BOTON BTN_SALIR CENSO DE REGRESAR A FRMMENUOP
      // no funciona
        if (e.getSource() == vistaD.btn_feo) { 
           vistaD.setVisible(false);
          frmMenuOp vs= new frmMenuOp();
          vs.setVisible(true);
         //
        }

        }
        //abrir vista del Dasbhboard
         if(e.getSource()== vistam.btn_dashboard1){
            Dashboard ds= new Dashboard();
           ds.setVisible(true);
        }
         
     
         
        /// boton salir frmMenu
          if (e.getSource() == vistam.btn_salir) { 
            

            Connection con = getConexion();
            try {
                System.out.println("Conexion cerrada");
                con.close();
                vistam.setVisible(false);
            } catch (SQLException ex) {
                Logger.getLogger(CtrlMenu.class.getName()).log(Level.SEVERE, null, ex);
            }

        }  

    }

}
